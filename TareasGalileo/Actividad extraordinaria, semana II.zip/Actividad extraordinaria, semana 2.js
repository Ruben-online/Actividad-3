// Genera el número aleatorio entre 1 y 9
let computer_number = Math.floor(Math.random() * 9) + 1;
let user_number;
let user_guess;

while (true) {
  // Solicita un número y lo convierte a número
  user_number = Number(prompt("Ingrese un número entre 3 y 6: "));

  // Verifica si el número está en el rango permitido
  if (user_number >= 3 && user_number <= 6) {
    // Solicita si el usuario cree que su número es "mayor" o "menor"
    user_guess = prompt("¿Crees que tu número es 'mayor' o 'menor' al que la PC escogió?").toLowerCase();

    // Compara el número del usuario con el de la computadora
    if ((user_guess === "mayor" && user_number > computer_number) || 
        (user_guess === "menor" && user_number < computer_number)) {
      console.log(`Tu número: ${user_number}`);
      console.log(`Número de la PC: ${computer_number}`);
      console.log("¡Ganaste!");
      break;
    } else if (user_number === computer_number) {
      console.log(`Tu número: ${user_number}`);
      console.log(`Número de la PC: ${computer_number}`);
      console.log("Empate, ambos eligieron el mismo número.");
      break;
    } else {
      console.log(`Tu número: ${user_number}`);
      console.log(`Número de la PC: ${computer_number}`);
      console.log("Perdiste. ¡Inténtalo de nuevo!");
      break;
    }
  } else {
    console.log("Número fuera de rango, intenta de nuevo.");
  }
}

// Pregunta si el usuario quiere jugar otra vez
let play_again = prompt("¿Quieres jugar otra vez? (si/no): ").toLowerCase();
if (play_again === "si") {
  // Genera un nuevo número aleatorio para la PC
  computer_number = Math.floor(Math.random() * 9) + 1;

  while (true) {
    // Solicita un número y lo convierte a número
    user_number = Number(prompt("Ingrese un número entre 3 y 6: "));

    // Verifica si el número está en el rango permitido
    if (user_number >= 3 && user_number <= 6) {
      // Solicita si el usuario cree que su número es "mayor" o "menor"
      user_guess = prompt("¿Crees que tu número es 'mayor' o 'menor' al que la PC escogió?").toLowerCase();

      // Compara el número del usuario con el de la computadora
      if ((user_guess === "mayor" && user_number > computer_number) || 
          (user_guess === "menor" && user_number < computer_number)) {
        console.log(`Tu número: ${user_number}`);
        console.log(`Número de la PC: ${computer_number}`);
        console.log("¡Ganaste!");
        break;
      } else if (user_number === computer_number) {
        console.log(`Tu número: ${user_number}`);
        console.log(`Número de la PC: ${computer_number}`);
        console.log("Empate, ambos eligieron el mismo número.");
        break;
      } else {
        console.log(`Tu número: ${user_number}`);
        console.log(`Número de la PC: ${computer_number}`);
        console.log("Perdiste. ¡Inténtalo de nuevo!");
        break;
      }
    } else {
      console.log("Número fuera de rango, intenta de nuevo.");
    }
  }
} else {
  console.log("Gracias por jugar, Rubén Espinoza - 25008248");
}