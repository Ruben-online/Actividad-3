console.log("¿Qué signo zodiacal eres?")

var month = parseInt(prompt("Ingrese su mes de nacimiento (1-12): "));
var day = parseInt(prompt("Ingrese el dia en que nacio (1-31): "));

if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) {
  alert("Usted es Aries!");
  
} else if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) {
  alert("Usted es Tauro!");
  
} else if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) {
  alert("Usted es Géminis!");
  
} else if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) {
  alert("Usted es Cancer!");

} else if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) {
  alert("Usted es Leo!");

} else if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) {
  alert("Usted es Virgo!");

} else if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) {
  alert("Usted es Libra!");

} else if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) {
  alert("Usted es Escorpio!");

} else if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) {
  alert("Usted es Sagitario!");

} else if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) {
  alert("Usted es Capricornio!");

} else if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) {
  alert("Usted es Acuario!");

} else if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) {
  alert("Usted es Piscis!");
}